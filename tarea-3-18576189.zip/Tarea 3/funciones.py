#!/usr/bin/env python
# -*- coding: utf-8 -*-
#Integrantes:
# 18.576.189-4 Nicolas Hermosilla
# 18.798.983-3 Felipe Diaz
# 18.798.946-9 Jose Araya

from definiciones import *

def obtener_correo(datos):
    correo=datos['nombre']+'.'+(datos['apellido1'].replace(' ',''))  
    if int(datos['ingreso']) < 2012:
        correo = correo+'@alumnos.usm.cl'
    else:
        correo = correo+'.'+datos['ingreso'][2:]+'@sansano.usm.cl'
    return correo.lower()

def obtener_password(datos):
    principio=datos['nombre'][0:3]
    medio=datos['apellido2'][-3:]
    final=str(len(datos['apellido1']))
    password=principio+medio+final
    return password.lower()

# Cuenta las lineas de un archivo de texto(util para el rol)
def numero_lineas(archivo):
    arch=open(archivo)
    n=0
    for i in arch:
        n+=1
    arch.close()
    return n
        
def obtener_rol(datos):
    rol=''
    if int(datos['ingreso']) < 2010:
        anno=datos['ingreso'][0]+datos['ingreso'][3]
    else:
        anno=datos['ingreso']
    carrera=datos['codigo']
    lugar=str(numero_lineas('alumnos.dat')+1)
    rol=anno+carrera+lugar
    lim=len(anno)+len(carrera)
    while len(rol) < (len(anno)+5):
        rol=rol[0:lim]+'0'+rol[lim:] 
    verificador=digito_verificador(rol)
    rol=rol+'-'+verificador
    return rol 
    
def guardar_datos(datos):
    archivo=open('alumnos.dat','a')
    nombre=datos['nombre'].upper()
    apellido1=datos['apellido1'].replace(' ','-').upper()
    apellido2=datos['apellido2'].replace(' ','-').upper()
    correo=obtener_correo(datos)
    rol=obtener_rol(datos)
    sexo=datos['sexo']
    codigo=datos['codigo']
    anno=datos['ingreso']
    password=obtener_password(datos)
    linea=correo+' '+rol+' '+nombre+'|'+apellido1+'|'+apellido2+' '+sexo+';'+codigo+';'+anno+';'+password+'\n'
    archivo.write(linea)
    archivo.close()
    ubicacion='alumnos/'+rol+'.dat'
    archivo.close()
    a=open(ubicacion,'w')
    a.close()
    return

def verificar_ingreso(correo, password):
    archivo=open('alumnos.dat')
    cont=0
    for linea in archivo:
        if linea.split()[0] == correo:
            cont=1
            if linea.split()[3].split(';')[3] == password:
                return True
                break
            else:
                return False
                break
    if cont==0:
        return False
    archivo.close()
    return
    
def obtener_datos(usuario):
    archivo=open('alumnos.dat')
    datos=dict()
    for linea in archivo:
        if linea.split('@')[0]==usuario:
            datos['nombre']=linea.split()[2].split('|')[0]
            datos['apellido1']=linea.split()[2].split('|')[1]
            datos['apellido2']=linea.split()[2].split('|')[2]
            datos['sexo']=linea.split()[3].split(';')[0]
            datos['carrera']=linea.split()[3].split(';')[1]
            datos['ingreso']=linea.split()[3].split(';')[2]
            datos['rol']=linea.split()[1]
            datos['correo']=linea.split()[0]
    datos['carrera']=codigos_carreras[datos['carrera']]
    archivo.close()
    return datos

def inscribir_asignaturas(usuario, asignaturas):
    rol=obtener_datos(usuario)['rol']
    datos='alumnos/'+rol+'.dat'
    inscritas=open(datos,'w')
    for j in asignaturas:
        inscritas.write(j+':-1\n')
    inscritas.close()
    return
    
def avance_curricular(usuario):
    notas = dict()
    rol=obtener_datos(usuario)['rol']
    datos='alumnos/'+rol+'.dat'
    asignaturas=open(datos)
    for linea in asignaturas:
        codigo=linea.split(':')[0]
        nota=linea.split(':')[1]
        if int(nota) >= 55:
            estado ='Aprobada'
        elif int(nota) >= 0:
            estado='Reprobada'
        else:
            estado='No Ingresada'
        notas[codigo]=(siglas_asignaturas[codigo],nota,estado)
    asignaturas.close()
    return notas
    
## BONUS ##

def obtener_alumnos_asignatura(asignatura):
    alumnos_asignatura = set()
    alumnos_raw=open('alumnos.dat')
    alumnos=[]
    for cada in alumnos_raw:
        alumnos.append(cada.split()[1])
    for rol in alumnos:
        datos=open('alumnos/'+rol+'.dat')
        for linea in datos:
            if linea.split(':')[0] == asignatura:
                alumnos_asignatura.add(rol)
                break
        datos.close()
    return alumnos_asignatura

def calificar_alumnos(asignatura, notas):
    for tupla in notas:
        rol=tupla[0]
        nota=tupla[1]
        result=''
        dat=open('alumnos/'+rol+'.dat',"r")
        for linea in dat:
            if linea.split(':')[0] == asignatura:
                l=asignatura+':'+str(nota)+'\n'
                result=result+l
            else:
                result=result+linea
        dat.close()
        dat=open('alumnos/'+rol+'.dat',"w")
        dat.write(result)
        dat.close()
    return
