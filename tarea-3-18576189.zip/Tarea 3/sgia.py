#!/usr/bin/env python
# -*- coding: utf-8 -*-

from bottle import route, run, get, post, request, static_file, redirect
from funciones import *
from datetime import *

@route('/static/:path#.+#', name='static')
def static(path):
    return static_file(path, root='static')
    
# Si se escribe en el navegador http://localhost:8080/ o 
# http://localhost:8080/tuiteos, entonces ejecuta esta funcion.
@route('/') 
def index():
    archivo = open("static/login.html")
    html = archivo.read()
    archivo.close()
    return html
 
@route('/login', method='POST')
def login():
    usuario = request.forms.get("usuario")
    mail = request.forms.get("mail")
    password = request.forms.get("password")
    
    if verificar_ingreso(usuario + mail, password):
        redirect('/' + usuario)
    else:
        redirect('/error')

@route('/:usuario')
def menu_principal(usuario):
    archivo = open("static/alumno.html")
    html = archivo.read()
    html = html.replace("<!--USUARIO-->", usuario)
    return html

@route('/error')
def error_login():
    archivo = open("static/login.html")
    html = archivo.read()
    html = html.replace("<!--MENSAJE-->", "Usuario y/o password incorrectos. Vuelva a intentarlo.")
    archivo.close()
    return html

@route('/:usuario/ficha')
def ficha(usuario):
    datos = obtener_datos(usuario)
    archivo = open("static/ficha.html")
    html = archivo.read()
    for llave in datos:
        html = html.replace("<!--"+llave.upper()+"-->", datos[llave])
    html = html.replace("<!--USUARIO-->", usuario)
    archivo.close()
    return html

@route('/:usuario/inscripcion')
def inscribir(usuario):
    archivo = open("static/inscripcion.html")
    html = archivo.read()
    html = html.replace("<!--USUARIO-->", usuario)
    return html
    
@route('/:usuario/inscripcion/enviar', method="POST")
def inscribir_confirmacion(usuario):
    asignaturas = request.forms.getall('asignaturas')
    inscribir_asignaturas(usuario, asignaturas)
    redirect('/'+usuario+'/inscripcion/confirmacion')

@route('/:usuario/inscripcion/confirmacion')
def confirmacion_inscripcion(usuario):
    archivo = open("static/confirmacion_inscripcion.html")
    html = archivo.read()
    html = html.replace("<!--USUARIO-->", usuario)
    archivo.close()
    return html

@route('/:usuario/avance')
def avance(usuario):
    notas = avance_curricular(usuario)
    
    html_notas = ''
    for sigla, (asignatura, nota, evaluacion) in notas.items():
        html_notas += "<tr>\n"
        html_notas += "<td>"+sigla+"</td>\n"
        html_notas += "<td>"+asignatura+"</td>\n"
        html_notas += "<td class=\"center\">"+nota+"</td>\n"
        html_notas += "<td>"+evaluacion+"</td>\n"
        html_notas += "</tr>\n"
        
    archivo = open("static/avance.html")
    html = archivo.read()
    html = html.replace("<!--NOTAS-->", html_notas)
    html = html.replace("<!--USUARIO-->", usuario)
    
    return html

@route('/registro')
def registro():
    archivo = open("static/registro.html")
    html = archivo.read()
    archivo.close()
    return html
    
@route('/registro/confirmacion', method="POST")
def confirmacion_registro():
    archivo = open("static/confirmacion.html")
    html = archivo.read()
    archivo.close()
    
    datos = {
    "nombre": request.forms.get('nombre'),
    "apellido1": request.forms.get('apellido1'),
    "apellido2": request.forms.get('apellido2'),
    "sexo": request.forms.get('sexo'),
    "codigo": request.forms.get('codigo'),
    "ingreso": request.forms.get('ingreso')
    }
    
    guardar_datos(datos)
    html = html.replace("<!--CORREO-->", obtener_correo(datos))
    html = html.replace("<!--PASSWORD-->", obtener_password(datos))
    return html

@route('/evaluaciones')
def evaluaciones():
    archivo = open("static/evaluaciones.html")
    html = archivo.read()
    archivo.close()
    return html

@route('/evaluaciones/enviar', method="POST")
def asignatura_a_evaluar():
    asignatura = request.forms.get('asignatura')
    if asignatura is not None:
        redirect('/evaluaciones/'+asignatura)
    else:
        redirect('/evaluaciones')

@route('/evaluaciones/:asignatura')
def calificar(asignatura):
    lista_rol = obtener_alumnos_asignatura(asignatura)
    
    html_notas = ''
    for rol in lista_rol:
        html_notas += "<tr>\n"
        html_notas += "<td class=\"rjust\"><label>"+rol+"</label></td>\n"
        html_notas += "<td><input type=\"text\" name=\""+rol+"\" size=\"3\" min=\"0\" max=\"100\" maxlength=\"3\" required></td>"
        html_notas += "</tr>\n"
    archivo = open("static/calificar.html")
    html = archivo.read()
    archivo.close()
    html = html.replace("<!--NOTAS-->", html_notas)
    html = html.replace("<!--ASIGNATURA-->", asignatura)
    return html

@route('/evaluaciones/:asignatura/enviar', method="POST")
def enviar_calificaciones(asignatura):
    lista_rol = obtener_alumnos_asignatura(asignatura)
    notas = []
    for rol in lista_rol:
        nota = request.forms.get(rol)
        notas.append((rol, nota))
        
    calificar_alumnos(asignatura, notas)
    
    archivo = open("static/confirmacion_notas.html")
    html = archivo.read()
    archivo.close()
    return html

# No borrar ni modificar
run(host='localhost', port=8080)

